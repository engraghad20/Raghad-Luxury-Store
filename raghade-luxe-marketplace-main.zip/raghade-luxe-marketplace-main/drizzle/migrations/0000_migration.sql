
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  sort_order int not null default 0
);
grant select on public.categories to anon, authenticated;
grant all on public.categories to service_role;
alter table public.categories enable row level security;
create policy "categories public read" on public.categories for select using (true);

create table public.products (
  id serial primary key,
  category_id uuid not null references public.categories(id),
  name text not null,
  brand text not null,
  description text not null default '',
  price numeric(10,2) not null,
  old_price numeric(10,2),
  rating numeric(2,1) not null default 5,
  image_url text not null,
  is_featured boolean not null default false,
  created_at timestamptz not null default now()
);
grant select on public.products to anon, authenticated;
grant all on public.products to service_role;
alter table public.products enable row level security;
create policy "products public read" on public.products for select using (true);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  city text,
  address text,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "own profile read" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update to authenticated using (auth.uid() = id);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'));
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('RL-' || to_char(now(),'YYMMDD') || '-' || upper(substr(md5(random()::text),1,5))),
  user_id uuid,
  full_name text not null,
  phone text not null,
  email text not null,
  city text not null,
  address text not null,
  payment_method text not null,
  subtotal numeric(10,2) not null,
  discount numeric(10,2) not null,
  tax numeric(10,2) not null,
  total numeric(10,2) not null,
  status text not null default 'confirmed',
  created_at timestamptz not null default now()
);
grant select on public.orders to authenticated;
grant all on public.orders to service_role;
alter table public.orders enable row level security;
create policy "own orders read" on public.orders for select to authenticated using (auth.uid() = user_id);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id int not null references public.products(id),
  product_name text not null,
  brand text not null,
  unit_price numeric(10,2) not null,
  old_price numeric(10,2),
  quantity int not null
);
grant select on public.order_items to authenticated;
grant all on public.order_items to service_role;
alter table public.order_items enable row level security;
create policy "own order items read" on public.order_items for select to authenticated
  using (exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));

create table public.newsletter_subscribers (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  created_at timestamptz not null default now()
);
grant insert on public.newsletter_subscribers to anon, authenticated;
grant all on public.newsletter_subscribers to service_role;
alter table public.newsletter_subscribers enable row level security;
create policy "anyone subscribe" on public.newsletter_subscribers for insert to anon, authenticated
  with check (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' and length(email) <= 255);

-- Places an order with prices computed from the products table; returns the invoice.
create or replace function public.place_order(
  _items jsonb, _full_name text, _phone text, _email text, _city text, _address text, _payment_method text
) returns jsonb language plpgsql security definer set search_path = public as $$
declare
  _order public.orders; _sub numeric := 0; _disc numeric := 0; _it jsonb; _p public.products; _q int;
begin
  if jsonb_typeof(_items) <> 'array' or jsonb_array_length(_items) = 0 then raise exception 'السلة فارغة'; end if;
  if coalesce(trim(_full_name),'') = '' or coalesce(trim(_phone),'') = '' or coalesce(trim(_city),'') = '' or coalesce(trim(_address),'') = '' then raise exception 'بيانات ناقصة'; end if;
  if _email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'بريد غير صالح'; end if;
  if _payment_method not in ('الدفع عند الاستلام','بطاقة ائتمانية','تحويل بنكي','Apple Pay') then raise exception 'طريقة دفع غير صالحة'; end if;
  for _it in select * from jsonb_array_elements(_items) loop
    _q := (_it->>'quantity')::int;
    if _q is null or _q < 1 or _q > 50 then raise exception 'كمية غير صالحة'; end if;
    select * into _p from public.products where id = (_it->>'product_id')::int;
    if not found then raise exception 'منتج غير موجود'; end if;
    _sub := _sub + _p.price * _q;
    _disc := _disc + greatest(coalesce(_p.old_price,_p.price) - _p.price, 0) * _q;
  end loop;
  insert into public.orders (user_id, full_name, phone, email, city, address, payment_method, subtotal, discount, tax, total)
  values (auth.uid(), left(_full_name,120), left(_phone,30), left(_email,255), left(_city,80), left(_address,300), _payment_method,
          _sub, _disc, round(_sub*0.15,2), round(_sub*1.15,2))
  returning * into _order;
  insert into public.order_items (order_id, product_id, product_name, brand, unit_price, old_price, quantity)
  select _order.id, p.id, p.name, p.brand, p.price, p.old_price, (i->>'quantity')::int
  from jsonb_array_elements(_items) i join public.products p on p.id = (i->>'product_id')::int;
  return jsonb_build_object('order', to_jsonb(_order), 'items',
    (select jsonb_agg(to_jsonb(oi)) from public.order_items oi where oi.order_id = _order.id));
end; $$;
revoke all on function public.place_order(jsonb,text,text,text,text,text,text) from public;
grant execute on function public.place_order(jsonb,text,text,text,text,text,text) to anon, authenticated;

insert into public.categories (slug, name, sort_order) values
 ('KIKO','KIKO',1),('Luxora','Luxora',2),('Bellezza','Bellezza',3),('YSL','Yves Saint Laurent',4);

insert into public.products (id, category_id, name, brand, description, price, old_price, rating, image_url, is_featured)
select v.id, c.id, v.name, v.brand, v.descr, 150, 199, v.rating, v.img, v.feat
from (values
 (1,'KIKO','KIKO Rouge','KIKO','مظهر عصري وأنيق يدوم طويلاً',4.8,'/__l5e/assets-v1/e35b05e3-92f2-4526-ac46-799cc71c453a/task3-1.jpg',true),
 (2,'KIKO','KIKO Rouge','KIKO','لإطلالة لامعة وجذابة',4.9,'/__l5e/assets-v1/88c60636-f70c-4143-847c-4c83c2f4decb/task3-2.jpg',false),
 (3,'KIKO','KIKO Rouge','KIKO','تغطية مثالية وإشراقة طبيعية',4.7,'/__l5e/assets-v1/347ff971-35cd-45e0-939e-b9a49dcf0dfd/task3-3.jpg',false),
 (4,'KIKO','KIKO Rouge','KIKO','تحافظ على نعومة الشفاه طوال',4.6,'/__l5e/assets-v1/0c7e4303-56f8-4f56-8606-ec6db0f2e910/task3-4.jpg',false),
 (5,'KIKO','KIKO Rouge','KIKO','توهج طبيعي يدوم طوال اليوم',4.8,'/__l5e/assets-v1/cb26c389-e7fe-4797-9d43-913ec66ba20c/task3-5.jpg',false),
 (6,'KIKO','KIKO Rouge','KIKO','عبوة أنيقة تضيف لمسة فخامة لمكياجك',4.5,'/__l5e/assets-v1/da800810-cfa9-4ba9-8b41-53446adc1204/task3-6.jpg',false),
 (7,'Luxora','Luxora Rouge','Luxora','لنظهري باجمل اطلاله دون الحاجة لتعديل مستمر',4.9,'/__l5e/assets-v1/2c906b82-a185-4df5-84d2-c798cea86ded/task3-7.jpg',true),
 (8,'Luxora','Luxora Rouge','Luxora','مرطب للعناية بالشفاه الجافة مع لمسة لون طبيعية',4.8,'/__l5e/assets-v1/6287f5af-c203-4515-bce8-7689e8621512/task3-8.jpg',false),
 (9,'Luxora','Luxora Rouge','Luxora','لون غني وثبات طويل دون جفاف',4.7,'/__l5e/assets-v1/420041be-c23e-4a38-b9dd-395c92d84253/task3-9.jpg',false),
 (10,'Luxora','Luxora Rouge','Luxora','ملمس مخملي ناعم لإطلالة راقية',4.9,'/__l5e/assets-v1/c3b696bf-9c87-4bd0-bc76-bd467051f113/task3-10.jpg',true),
 (11,'Bellezza','Bellezza Rouge','Bellezza','فخامة إيطالية بتركيبة مغذية',4.8,'/__l5e/assets-v1/8c03fce7-969c-4fb4-aca8-fade047f1b91/task3-12.jpg',true),
 (12,'Bellezza','Bellezza Rouge','Bellezza','رسم دقيق وثبات احترافي',4.7,'/__l5e/assets-v1/b2534c0f-6ad7-4dc8-954f-dfbe4212ab8e/task3-13.jpg',false),
 (13,'Bellezza','Bellezza Rouge','Bellezza','لإطلالة لامعة وجذابة',4.9,'/__l5e/assets-v1/0133ba90-b2a7-4f00-9f68-4327a8866166/task3-14.jpg',false),
 (14,'Bellezza','Bellezza Rouge','Bellezza','عناية فاخرة لشفاه ناعمة كالحرير',4.6,'/__l5e/assets-v1/289a02f2-a2ba-422a-be0f-bd1a0438bf7e/task3-15.jpg',false),
 (15,'Bellezza','Bellezza Rouge','Bellezza','مظهر عصري وأنيق يدوم طويلاً',4.8,'/__l5e/assets-v1/4192cbd7-eb07-4f81-9e3b-f6322b6c2f36/task3-16.jpg',false),
 (16,'Bellezza','Bellezza Rouge','Bellezza','مرطب للعناية بالشفاه الجافة مع لمسة لون طبيعية',4.5,'/__l5e/assets-v1/43cf3491-8ace-460f-a763-fdbcc89466a6/task3-17.jpg',false),
 (17,'YSL','YSL Rouge','Yves Saint Laurent','عبوة أنيقة تضيف لمسة فخامة لمكياجك',5.0,'/__l5e/assets-v1/2b20807a-d9db-4615-94bf-074ffcd334d6/task3-18.jpeg',true),
 (18,'YSL','YSL Rouge','Yves Saint Laurent','تحضير مثالي لتطبيق سلس وثابت',4.9,'/__l5e/assets-v1/0d7fc773-fe78-4134-8c91-650d2a2305fb/task3-19.jpeg',false),
 (19,'YSL','YSL Rouge','Yves Saint Laurent','لإطلالة لامعة وجذابة',5.0,'/__l5e/assets-v1/2bedc642-4bac-4a57-a541-591be711c902/task3-20.jpeg',true),
 (20,'YSL','YSL Rouge','Yves Saint Laurent','مرطب للعناية بالشفاه الجافة مع لمسة لون طبيعية',4.8,'/__l5e/assets-v1/f6ae830d-821e-42e0-9bb0-36f88e3f5893/task3-22.jpeg',false),
 (21,'YSL','YSL Rouge','Yves Saint Laurent','مظهر عصري وأنيق يدوم طويلاً',4.9,'/__l5e/assets-v1/d83a1ec0-fe75-438d-a359-253bf7966cf5/task3-23.jpeg',false),
 (22,'YSL','YSL Rouge','Yves Saint Laurent','ثبات استثنائي يدوم حتى 8 ساعات',4.7,'/__l5e/assets-v1/24849668-ba7b-4a6d-b806-43a153ebe58f/task3-24.jpeg',false),
 (23,'YSL','YSL Rouge','Yves Saint Laurent','ملمس خفيف منعش لإطلالة طبيعية',5.0,'/__l5e/assets-v1/20831b1b-e39a-4302-bed6-98d00c241f68/task3-26.jpeg',false)
) as v(id,cat,name,brand,descr,rating,img,feat)
join public.categories c on c.slug = v.cat;
select setval('public.products_id_seq', 23);
