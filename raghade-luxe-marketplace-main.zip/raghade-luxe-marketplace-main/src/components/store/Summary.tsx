import { sar } from "@/lib/pricing";

export function Summary({ totals }: { totals: { subtotal: number; discount: number; tax: number; total: number } }) {
  return (
    <div className="bg-secondary p-8">
      <h3 className="font-display text-2xl">ملخص الطلب</h3>
      <dl className="mt-6 space-y-3 text-sm">
        <div className="flex justify-between"><dt>المجموع الفرعي</dt><dd>{sar(totals.subtotal)}</dd></div>
        <div className="flex justify-between"><dt>التوفير</dt><dd className="text-success">−{sar(totals.discount)}</dd></div>
        <div className="flex justify-between"><dt>ضريبة القيمة المضافة (15%)</dt><dd>{sar(totals.tax)}</dd></div>
        <div className="flex justify-between border-t border-border pt-4 text-lg font-bold"><dt>الإجمالي</dt><dd>{sar(totals.total)}</dd></div>
      </dl>
    </div>
  );
}
