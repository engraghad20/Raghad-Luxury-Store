import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="no-print mt-24 bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-4 lg:px-8">
        <div className="space-y-3">
          <h3 className="font-display text-2xl" dir="ltr">
            Raghade' <span className="text-gold-gradient">Luxury</span>
          </h3>
          <p className="text-sm opacity-70">متجرك الأول لأفخم منتجات المكياج العالمية</p>
          <p className="font-display text-sm italic opacity-60" dir="ltr">Luxury Makeup for the Elegant You</p>
          <p className="text-sm opacity-70">تجربة تسوق فاخرة لا تُنسى</p>
        </div>
        <div>
          <h4 className="mb-4 text-xs font-bold tracking-[0.2em] text-gold">روابط سريعة</h4>
          <ul className="space-y-2 text-sm opacity-80">
            <li><Link to="/" className="hover:text-gold">الرئيسية</Link></li>
            <li><Link to="/products" className="hover:text-gold">المنتجات</Link></li>
            <li><Link to="/about" className="hover:text-gold">من نحن</Link></li>
            <li><Link to="/contact" className="hover:text-gold">تواصل معنا</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 text-xs font-bold tracking-[0.2em] text-gold">خدمة العملاء</h4>
          <ul className="space-y-2 text-sm opacity-80">
            <li>سياسة الإرجاع</li>
            <li>الشحن والتوصيل</li>
            <li>الأسئلة الشائعة</li>
            <li>سياسة الخصوصية</li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 text-xs font-bold tracking-[0.2em] text-gold">تواصل معنا</h4>
          <ul className="space-y-2 text-sm opacity-80">
            <li><a href="mailto:raghad.alshawafy2023@icloud.com" className="hover:text-gold" dir="ltr">raghad.alshawafy2023@icloud.com</a></li>
            <li>خدمة العملاء 24/7</li>
            <li>نشحن لجميع أنحاء المملكة</li>
            <li>عروض حصرية يومياً</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-ink-foreground/10 py-6 text-center text-xs opacity-60">
        © {new Date().getFullYear()} Raghade' Luxury Store. جميع الحقوق محفوظة
      </div>
    </footer>
  );
}
