import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export function AuthDialog({
  mode,
  onModeChange,
  open,
  onOpenChange,
}: {
  mode: "login" | "register";
  onModeChange: (m: "login" | "register") => void;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email")).trim();
    const password = String(f.get("password"));
    setBusy(true);
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("أهلاً بعودتك ✨");
        onOpenChange(false);
      } else {
        const full_name = String(f.get("name")).trim();
        if (password !== String(f.get("confirm"))) throw new Error("كلمتا المرور غير متطابقتين");
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin, data: { full_name } },
        });
        if (error) throw error;
        toast.success("تم إنشاء الحساب — تحققي من بريدك لتأكيد التسجيل");
        onOpenChange(false);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "حدث خطأ");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent dir="rtl" className="sm:max-w-md">
        <DialogHeader className="text-right sm:text-right">
          <DialogTitle className="font-display text-3xl">
            {mode === "login" ? "تسجيل الدخول" : "إنشاء حساب جديد"}
          </DialogTitle>
          <DialogDescription>Raghade' Luxury</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          {mode === "register" && (
            <div className="space-y-2">
              <Label htmlFor="name">الاسم الكامل</Label>
              <Input id="name" name="name" required maxLength={120} />
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="email">البريد الإلكتروني</Label>
            <Input id="email" name="email" type="email" dir="ltr" required maxLength={255} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">كلمة المرور</Label>
            <Input id="password" name="password" type="password" dir="ltr" required minLength={6} />
          </div>
          {mode === "register" && (
            <div className="space-y-2">
              <Label htmlFor="confirm">تأكيد كلمة المرور</Label>
              <Input id="confirm" name="confirm" type="password" dir="ltr" required minLength={6} />
            </div>
          )}
          <Button type="submit" disabled={busy} className="h-12 w-full rounded-none tracking-wide">
            {busy ? "..." : mode === "login" ? "دخول" : "إنشاء الحساب"}
          </Button>
          <button
            type="button"
            onClick={() => onModeChange(mode === "login" ? "register" : "login")}
            className="w-full text-sm text-muted-foreground hover:text-foreground"
          >
            {mode === "login" ? "ليس لديك حساب؟ سجّلي الآن" : "لديك حساب؟ سجّلي الدخول"}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
