import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag, User, X } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import logo from "@/assets/products/Log.jpeg.asset.json";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { AuthDialog } from "./AuthDialog";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "الرئيسية" },
  { to: "/products", label: "المنتجات" },
  { to: "/about", label: "من نحن" },
  { to: "/contact", label: "تواصل معنا" },
] as const;

export function SiteHeader() {
  const { count } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [q, setQ] = useState("");
  const [auth, setAuth] = useState<{ open: boolean; mode: "login" | "register" }>({ open: false, mode: "login" });

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  function search(e: React.FormEvent) {
    e.preventDefault();
    setMobile(false);
    navigate({ to: "/products", search: { q: q.trim() || undefined } });
  }

  return (
    <header
      className={cn(
        "no-print sticky top-0 z-50 border-b transition-colors duration-300",
        scrolled ? "border-border bg-background/85 backdrop-blur-xl" : "border-transparent bg-background",
      )}
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center gap-6 px-5 lg:px-8">
        <Link to="/" className="flex shrink-0 items-center gap-3">
          <img src={logo.url} alt="شعار Raghade' Luxury" className="h-11 w-11 rounded-full object-cover ring-1 ring-gold/50" />
          <span className="font-display text-xl font-semibold tracking-tight" dir="ltr">
            Raghade' <span className="text-gold-gradient">Luxury</span>
          </span>
        </Link>

        <nav className="hidden flex-1 justify-center gap-8 lg:flex">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: true }}
              className="relative text-sm font-medium text-muted-foreground transition-colors hover:text-foreground data-[status=active]:text-foreground data-[status=active]:after:absolute data-[status=active]:after:-bottom-2 data-[status=active]:after:inset-x-0 data-[status=active]:after:h-px data-[status=active]:after:bg-gold"
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="ms-auto flex items-center gap-2 lg:ms-0">
          <form onSubmit={search} className="relative hidden md:block">
            <Search className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحثي عن المنتجات..."
              aria-label="بحث"
              className="h-10 w-56 rounded-full border border-border bg-card ps-9 pe-4 text-sm outline-none transition focus:w-64 focus:border-gold"
            />
          </form>
          {user ? (
            <button
              onClick={async () => {
                await supabase.auth.signOut();
                toast("تم تسجيل الخروج");
              }}
              className="hidden h-10 items-center gap-2 rounded-full px-3 text-sm text-muted-foreground hover:text-foreground sm:flex"
              title={user.email ?? ""}
            >
              <User className="h-4 w-4" /> خروج
            </button>
          ) : (
            <div className="hidden items-center gap-1 sm:flex">
              <button
                onClick={() => setAuth({ open: true, mode: "login" })}
                className="h-10 rounded-full px-4 text-sm font-medium hover:bg-muted"
              >
                دخول
              </button>
              <button
                onClick={() => setAuth({ open: true, mode: "register" })}
                className="h-10 rounded-full bg-primary px-5 text-sm font-medium text-primary-foreground transition hover:opacity-90"
              >
                تسجيل
              </button>
            </div>
          )}
          <Link to="/cart" className="relative flex h-10 w-10 items-center justify-center rounded-full hover:bg-muted" aria-label="السلة">
            <ShoppingBag className="h-5 w-5" />
            <AnimatePresence>
              {count > 0 && (
                <motion.span
                  key={count}
                  initial={{ scale: 0.4, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  className="absolute -end-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-gold px-1 text-[11px] font-bold text-accent-foreground"
                >
                  {count}
                </motion.span>
              )}
            </AnimatePresence>
          </Link>
          <button className="flex h-10 w-10 items-center justify-center lg:hidden" onClick={() => setMobile((m) => !m)} aria-label="القائمة">
            {mobile ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobile && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-border bg-background lg:hidden"
          >
            <div className="space-y-4 px-5 py-6">
              <form onSubmit={search} className="relative">
                <Search className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="ابحثي عن المنتجات..."
                  className="h-11 w-full rounded-full border border-border bg-card ps-9 pe-4 text-sm outline-none focus:border-gold"
                />
              </form>
              {NAV.map((n) => (
                <Link key={n.to} to={n.to} onClick={() => setMobile(false)} className="block font-display text-2xl">
                  {n.label}
                </Link>
              ))}
              {!user ? (
                <div className="flex gap-2 pt-2">
                  <button onClick={() => { setMobile(false); setAuth({ open: true, mode: "login" }); }} className="h-11 flex-1 rounded-full border border-border">دخول</button>
                  <button onClick={() => { setMobile(false); setAuth({ open: true, mode: "register" }); }} className="h-11 flex-1 rounded-full bg-primary text-primary-foreground">تسجيل</button>
                </div>
              ) : (
                <button onClick={() => supabase.auth.signOut()} className="h-11 w-full rounded-full border border-border">تسجيل الخروج</button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AuthDialog
        open={auth.open}
        mode={auth.mode}
        onOpenChange={(open) => setAuth((a) => ({ ...a, open }))}
        onModeChange={(mode) => setAuth({ open: true, mode })}
      />
    </header>
  );
}
