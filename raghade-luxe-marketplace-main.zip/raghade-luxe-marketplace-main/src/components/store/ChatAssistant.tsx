import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Send, X, RotateCcw } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { askAssistant } from "@/lib/assistant.functions";

type Msg = { role: "user" | "assistant"; content: string };
const KEY = "rl-assistant-v1";
const HELLO: Msg = { role: "assistant", content: "أهلاً حبيبتي 🌸 أنا **لولو** مساعدتك في Raghade' Luxury. كيف أقدر أساعدك اليوم؟ 💄" };
const SUGGEST = ["ايش اقل سعر منتج عندكم؟", "رشحي لي أفضل المنتجات ✨", "كيف أتمم طلبي؟"];

function Bow({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden>
      <circle cx="24" cy="26" r="16" className="fill-card" />
      <circle cx="18" cy="25" r="2" className="fill-foreground" />
      <circle cx="30" cy="25" r="2" className="fill-foreground" />
      <path d="M19 31q5 4 10 0" className="stroke-foreground" strokeWidth="2" fill="none" strokeLinecap="round" />
      <circle cx="14" cy="30" r="2.5" className="fill-gold-soft" />
      <circle cx="34" cy="30" r="2.5" className="fill-gold-soft" />
      <path d="M24 10l-9-5v10zM24 10l9-5v10z" className="fill-gold" />
      <circle cx="24" cy="10" r="2.5" className="fill-gold" />
    </svg>
  );
}

export function ChatAssistant() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([HELLO]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  const inp = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setMsgs(JSON.parse(raw));
    } catch { /* ignore */ }
  }, []);
  useEffect(() => {
    end.current?.scrollIntoView({ behavior: "smooth" });
    if (open && !busy) inp.current?.focus();
  }, [msgs, open, busy]);

  async function send(q: string) {
    q = q.trim();
    if (!q || busy) return;
    const next = [...msgs, { role: "user" as const, content: q }];
    setMsgs(next);
    setText("");
    setBusy(true);
    try {
      const { reply } = await askAssistant({ data: { messages: next.filter((m) => m !== HELLO).slice(-20) } });
      const done = [...next, { role: "assistant" as const, content: reply }];
      setMsgs(done);
      localStorage.setItem(KEY, JSON.stringify(done));
    } catch {
      setMsgs([...next, { role: "assistant", content: "عذراً، صار خطأ بسيط 🌸 حاولي مرة ثانية." }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="no-print fixed bottom-5 left-5 z-[60]" dir="rtl">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ type: "spring", stiffness: 300, damping: 24 }}
            className="mb-4 flex h-[560px] max-h-[75vh] w-[min(380px,calc(100vw-2.5rem))] flex-col overflow-hidden rounded-[28px] border border-gold/40 bg-background shadow-soft"
          >
            <div className="flex items-center gap-3 bg-ink px-4 py-3 text-ink-foreground">
              <motion.div animate={{ rotate: [0, -8, 8, 0] }} transition={{ repeat: Infinity, duration: 3 }}>
                <Bow className="h-11 w-11" />
              </motion.div>
              <div className="flex-1">
                <div className="font-bold">لولو 🎀</div>
                <div className="text-xs opacity-70">مساعدتك الفاخرة · متصلة الآن</div>
              </div>
              <button aria-label="محادثة جديدة" onClick={() => { setMsgs([HELLO]); localStorage.removeItem(KEY); }} className="rounded-full p-2 hover:bg-ink-foreground/10"><RotateCcw className="h-4 w-4" /></button>
              <button aria-label="إغلاق" onClick={() => setOpen(false)} className="rounded-full p-2 hover:bg-ink-foreground/10"><X className="h-4 w-4" /></button>
            </div>

            <div className="flex-1 space-y-3 overflow-y-auto bg-secondary/50 p-4">
              {msgs.map((m, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={m.role === "user" ? "flex justify-start" : "flex justify-end"}>
                  <div className={m.role === "user"
                    ? "max-w-[85%] rounded-3xl rounded-br-md bg-primary px-4 py-2.5 text-sm text-primary-foreground"
                    : "prose prose-sm max-w-[90%] text-sm leading-relaxed text-foreground [&_a]:text-gold [&_p]:my-1 [&_ul]:my-1"}>
                    {m.role === "user" ? m.content : <ReactMarkdown>{m.content}</ReactMarkdown>}
                  </div>
                </motion.div>
              ))}
              {busy && (
                <div className="flex justify-end gap-1 px-2">
                  {[0, 1, 2].map((d) => (
                    <motion.span key={d} className="h-2 w-2 rounded-full bg-gold" animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.8, delay: d * 0.15 }} />
                  ))}
                </div>
              )}
              {msgs.length === 1 && (
                <div className="flex flex-wrap gap-2 pt-2">
                  {SUGGEST.map((s) => (
                    <button key={s} onClick={() => send(s)} className="rounded-full border border-gold/50 bg-card px-3 py-1.5 text-xs hover:bg-gold/10">{s}</button>
                  ))}
                </div>
              )}
              <div ref={end} />
            </div>

            <form onSubmit={(e) => { e.preventDefault(); send(text); }} className="flex items-end gap-2 border-t border-border p-3">
              <textarea
                ref={inp}
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(text); } }}
                rows={1}
                maxLength={2000}
                placeholder="اكتبي سؤالك هنا..."
                className="max-h-28 min-h-11 flex-1 resize-none rounded-2xl border border-border bg-card px-4 py-2.5 text-sm outline-none focus:border-gold"
              />
              <button disabled={busy || !text.trim()} aria-label="إرسال" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gold text-accent-foreground transition disabled:opacity-40">
                <Send className="h-4 w-4 -scale-x-100" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setOpen((o) => !o)}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
        animate={open ? {} : { y: [0, -6, 0] }}
        transition={{ repeat: Infinity, duration: 2.4 }}
        aria-label="مساعدة المتجر"
        className="relative flex h-16 w-16 items-center justify-center rounded-full bg-ink shadow-soft ring-2 ring-gold"
      >
        {open ? <X className="h-6 w-6 text-gold" /> : <Bow className="h-12 w-12" />}
        {!open && <span className="absolute -top-1 -right-1 flex h-4 w-4 rounded-full bg-gold ring-2 ring-background" />}
      </motion.button>
    </div>
  );
}
