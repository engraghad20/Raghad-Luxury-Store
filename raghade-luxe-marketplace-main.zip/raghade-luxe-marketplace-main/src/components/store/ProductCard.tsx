import { motion } from "framer-motion";
import { Plus, Star } from "lucide-react";
import { toast } from "sonner";
import type { Product } from "@/lib/store";
import { useCart } from "@/lib/cart";
import { sar } from "@/lib/pricing";

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const { add } = useCart();
  const off = product.old_price ? Math.round((1 - product.price / product.old_price) * 100) : 0;
  return (
    <motion.article
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, delay: (index % 4) * 0.06, ease: [0.22, 1, 0.36, 1] }}
      className="group flex flex-col"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-muted">
        <img
          src={product.image_url}
          alt={`${product.name} — ${product.description}`}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
        {off > 0 && (
          <span className="absolute start-3 top-3 bg-background/90 px-2.5 py-1 text-[11px] font-bold tracking-wider backdrop-blur">
            -{off}%
          </span>
        )}
        <button
          onClick={() => {
            add(product);
            toast.success("أضيف إلى السلة", { description: product.name });
          }}
          className="absolute inset-x-3 bottom-3 flex h-11 translate-y-2 items-center justify-center gap-2 bg-primary text-sm font-medium text-primary-foreground opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 focus-visible:translate-y-0 focus-visible:opacity-100 max-md:translate-y-0 max-md:opacity-100"
        >
          <Plus className="h-4 w-4" /> أضيفي للسلة
        </button>
      </div>
      <div className="flex flex-1 flex-col gap-1.5 pt-4">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold tracking-[0.2em] text-gold" dir="ltr">{product.brand.toUpperCase()}</span>
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-3 w-3 fill-gold text-gold" /> {product.rating.toFixed(1)}
          </span>
        </div>
        <h3 className="font-display text-lg leading-snug" dir="ltr" style={{ textAlign: "right" }}>{product.name}</h3>
        <p className="line-clamp-2 text-sm text-muted-foreground">{product.description}</p>
        <div className="mt-auto flex items-baseline gap-2 pt-2">
          <span className="font-semibold">{sar(product.price)}</span>
          {product.old_price && <span className="text-sm text-muted-foreground line-through">{sar(product.old_price)}</span>}
        </div>
      </div>
    </motion.article>
  );
}
