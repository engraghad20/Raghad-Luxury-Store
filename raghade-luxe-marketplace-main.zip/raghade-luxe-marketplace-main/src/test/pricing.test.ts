import { describe, expect, it } from "vitest";
import { computeTotals } from "@/lib/pricing";

describe("order totals", () => {
  it("applies 15% VAT on the discounted subtotal", () => {
    const t = computeTotals([{ price: 150, old_price: 199, quantity: 2 }]);
    expect(t.subtotal).toBe(300);
    expect(t.discount).toBe(98);
    expect(t.tax).toBe(45);
    expect(t.total).toBe(345);
  });
});
