export const VAT_RATE = 0.15;

type Line = { price: number; old_price: number | null; quantity: number };

/** Mirrors the database place_order() calculation: VAT 15% on the discounted subtotal. */
export function computeTotals(items: Line[]) {
  const subtotal = items.reduce((s, i) => s + Number(i.price) * i.quantity, 0);
  const discount = items.reduce(
    (s, i) => s + Math.max(Number(i.old_price ?? i.price) - Number(i.price), 0) * i.quantity,
    0,
  );
  const tax = Math.round(subtotal * VAT_RATE * 100) / 100;
  const total = Math.round((subtotal + tax) * 100) / 100;
  return { subtotal, discount, tax, total };
}

export const sar = (n: number) =>
  `${new Intl.NumberFormat("ar-SA-u-nu-latn", { maximumFractionDigits: 2 }).format(Number(n))} ر.س`;
