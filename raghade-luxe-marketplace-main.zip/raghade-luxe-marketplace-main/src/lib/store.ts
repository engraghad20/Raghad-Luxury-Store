import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Product = {
  id: number;
  name: string;
  brand: string;
  description: string;
  price: number;
  old_price: number | null;
  rating: number;
  image_url: string;
  is_featured: boolean;
  category: { slug: string; name: string } | null;
};

export type Category = { id: string; slug: string; name: string };

export const productsQuery = () =>
  queryOptions({
    queryKey: ["products"],
    queryFn: async (): Promise<Product[]> => {
      const { data, error } = await supabase
        .from("products")
        .select("id,name,brand,description,price,old_price,rating,image_url,is_featured,category:categories(slug,name)")
        .order("id");
      if (error) throw error;
      return (data ?? []).map((p) => ({
        ...p,
        price: Number(p.price),
        old_price: p.old_price == null ? null : Number(p.old_price),
        rating: Number(p.rating),
      })) as Product[];
    },
    staleTime: 60_000,
  });

export const categoriesQuery = () =>
  queryOptions({
    queryKey: ["categories"],
    queryFn: async (): Promise<Category[]> => {
      const { data, error } = await supabase.from("categories").select("id,slug,name").order("sort_order");
      if (error) throw error;
      return data ?? [];
    },
    staleTime: 300_000,
  });

export type Invoice = {
  order: {
    id: string;
    order_number: string;
    full_name: string;
    phone: string;
    email: string;
    city: string;
    address: string;
    payment_method: string;
    subtotal: number;
    discount: number;
    tax: number;
    total: number;
    created_at: string;
  };
  items: { id: string; product_name: string; brand: string; unit_price: number; old_price: number | null; quantity: number }[];
};

export const PAYMENT_METHODS = ["الدفع عند الاستلام", "بطاقة ائتمانية", "تحويل بنكي", "Apple Pay"] as const;
