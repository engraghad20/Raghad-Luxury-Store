import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  messages: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(2000) }))
    .min(1)
    .max(30),
});

export const askAssistant = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const { createClient } = await import("@supabase/supabase-js");
    const { generateResponse, GatewayError } = await import("@lovable.dev/ai-gateway");
    const sb = createClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!, {
      auth: { persistSession: false },
    });
    const { data: products, error } = await sb
      .from("products")
      .select("id,name,brand,price,old_price,rating,category:categories(name)")
      .order("price");
    if (error) return { reply: "عذراً، تعذّر الوصول لقائمة المنتجات حالياً 🌸 حاولي بعد قليل." };

    const catalog = (products ?? [])
      .map((p: any) => `- [${p.id}] ${p.name} | الماركة: ${p.brand} | التصنيف: ${p.category?.name ?? "-"} | السعر: ${p.price} ر.س${p.old_price ? ` (بدلاً من ${p.old_price})` : ""} | التقييم: ${p.rating}/5`)
      .join("\n");

    const instructions = `أنتِ "لولو"، مساعدة متجر Raghade' Luxury للمكياج الفاخر. تتحدثين بالعربية بأسلوب راقٍ ولطيف وودود مع إيموجي خفيف (💄✨🌸).
قواعد صارمة:
- أجيبي فقط عن المتجر ومنتجاته وأسعاره وسياساته الواردة أدناه. لا تخترعي أي منتج أو سعر أو سياسة غير موجودة. إن لم تعرفي المعلومة قولي ذلك بلطف واقترحي صفحة "تواصل معنا".
- إذا سُئلتِ عن موضوع خارج المتجر اعتذري بلطف وأعيدي الحديث للمتجر.
- للمقارنة (أرخص/أغلى/أعلى تقييماً) اعتمدي حرفياً على البيانات واذكري اسم المنتج وسعره.
- للترشيح اعتمدي على التقييم والماركة.
- للمساعدة في الشراء: أرشدي لصفحة "المنتجات" (/products) لإضافة المنتج للسلة، ثم "السلة" (/cart)، ثم "إتمام الطلب" (/checkout).
- إجابات قصيرة ومنظمة.
سياسات المتجر: ضريبة القيمة المضافة 15% تُضاف على المجموع بعد الخصم. طرق الدفع: الدفع عند الاستلام، بطاقة ائتمانية، تحويل بنكي، Apple Pay. يمكن الطلب كضيفة بدون حساب، وتصدر فاتورة بعد الطلب.
المنتجات (${products?.length ?? 0} منتج، مرتبة من الأرخص للأغلى):
${catalog}`;

    try {
      const res = await generateResponse({
        model: "openai/gpt-6-astra",
        instructions,
        input: data.messages.map((m) => ({ role: m.role, content: m.content })),
      });
      const text = (res.output ?? [])
        .flatMap((o: any) => (o.type === "message" ? o.content : []))
        .filter((c: any) => c.type === "output_text")
        .map((c: any) => c.text)
        .join("");
      return { reply: text || "عذراً، لم أفهم سؤالك 🌸 ممكن تعيدينه؟" };
    } catch (e) {
      console.error(e instanceof GatewayError ? e.code : e);
      return { reply: "عذراً، المساعدة مشغولة حالياً 🌸 حاولي بعد لحظات." };
    }
  });
