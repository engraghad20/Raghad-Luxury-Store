import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Star } from "lucide-react";
import { productsQuery } from "@/lib/store";
import { ProductCard } from "@/components/store/ProductCard";
import { supabase } from "@/integrations/supabase/client";
import heroImg from "@/assets/hero-cinematic.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Raghade' Luxury — مكياج فاخر للأنيقة" },
      { name: "description", content: "مرحباً بك في عالم الفخامة: أحمر شفاه فاخر من KIKO وLuxora وBellezza وYSL بعروض حصرية." },
      { property: "og:title", content: "Raghade' Luxury — مكياج فاخر للأنيقة" },
      { property: "og:description", content: "تجربة تسوق حقيقية وفاخرة — Luxury Makeup for the Elegant You." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQuery()),
  component: Home,
});

const STATS = [
  { n: "500+", l: "عميلة سعيدة" },
  { n: "23", l: "منتج فاخر" },
  { n: "4.9", l: "تقييم العملاء" },
  { n: "24/7", l: "خدمة التوصيل" },
];

const REVIEWS = [
  { name: "نورة العتيبي", text: "منتجات رائعة وجودة عالية! التوصيل كان سريع والتغليف فاخر جداً. أنصح بالتسوق من هذا المتجر" },
  { name: "ريم السالم", text: "أفضل موقع للمكياج في السعودية! المنتجات أصلية 100% وخدمة العملاء ممتازة. تجربة تسوق رائعة" },
  { name: "سارة الشمري", text: "تجربة تسوق فاخرة! الأسعار منافسة والمنتجات ذات جودة عالية. سأكرر الشراء بكل تأكيد" },
];

function useCountdown() {
  const [left, setLeft] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const end = new Date(now);
      end.setHours(24, 0, 0, 0);
      setLeft(Math.max(0, Math.floor((end.getTime() - now.getTime()) / 1000)));
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);
  if (left == null) return ["--", "--", "--"];
  return [Math.floor(left / 3600), Math.floor((left % 3600) / 60), left % 60].map((v) => String(v).padStart(2, "0"));
}

function Home() {
  const { data: products } = useSuspenseQuery(productsQuery());
  const featured = products.filter((p) => p.is_featured).slice(0, 8);
  const [h, m, s] = useCountdown();

  async function subscribe(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const email = String(new FormData(form).get("email")).trim().toLowerCase();
    const { error } = await supabase.from("newsletter_subscribers").insert({ email });
    if (error && error.code !== "23505") { toast.error("تعذر الاشتراك، حاولي مجدداً"); return; }
    toast.success("شكراً لاشتراكك! 💌");
    form.reset();
  }

  return (
    <>
      {/* HERO */}
      <section className="relative isolate -mt-px flex min-h-[calc(100vh-5rem)] items-center overflow-hidden bg-ink text-ink-foreground">
        <motion.img
          src={heroImg}
          alt="أحمر شفاه وعطر فاخر بإضاءة ذهبية"
          width={1600}
          height={1008}
          initial={{ scale: 1.15, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 2.2, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0 -z-20 h-full w-full object-cover"
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-l from-ink via-ink/75 to-ink/10" />
        <div className="absolute inset-x-0 bottom-0 -z-10 h-40 bg-gradient-to-t from-ink to-transparent" />
        {Array.from({ length: 18 }).map((_, i) => (
          <motion.span
            key={i}
            className="absolute -z-10 h-1 w-1 rounded-full bg-gold"
            style={{ left: `${(i * 53) % 100}%`, top: `${(i * 37) % 100}%` }}
            animate={{ y: [0, -40, 0], opacity: [0, 0.9, 0] }}
            transition={{ repeat: Infinity, duration: 4 + (i % 5), delay: i * 0.3 }}
          />
        ))}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.1, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto w-full max-w-7xl px-5 py-24 lg:px-8"
        >
          <div className="max-w-2xl">
            <p className="mb-6 text-xs font-bold tracking-[0.4em] text-gold">LUXURY MAKEUP</p>
            <h1 className="font-display text-5xl font-medium leading-[1.15] md:text-7xl">
              مرحباً بك في عالم الفخامة
              <span className="mt-3 block text-gold-gradient italic" dir="ltr" style={{ textAlign: "right" }}>
                Raghade' Luxury
              </span>
            </h1>
            <div className="my-8 h-px w-32 bg-gradient-to-l from-gold to-transparent" />
            <p className="max-w-md text-lg opacity-80">
              تجربة تسوق حقيقية وفاخرة — <span dir="ltr">Luxury Makeup for the Elegant You</span>
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Link
                to="/products"
                className="group inline-flex h-14 items-center gap-3 bg-gold px-8 text-sm font-bold tracking-wide text-accent-foreground transition hover:opacity-90"
              >
                تسوقي الآن <ArrowLeft className="h-4 w-4 transition group-hover:-translate-x-1" />
              </Link>
              <Link to="/about" className="inline-flex h-14 items-center border border-gold/50 px-6 text-sm font-medium transition hover:bg-gold/10">
                اكتشفي قصتنا
              </Link>
            </div>
          </div>
        </motion.div>
      </section>

      {/* OFFER TIMER */}
      <section className="bg-ink text-ink-foreground">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-5 py-10 md:flex-row lg:px-8">
          <div>
            <h2 className="font-display text-3xl">عروض حصرية لفترة محدودة</h2>
            <p className="mt-1 text-sm opacity-70">خصم 25% على جميع المنتجات — ينتهي العرض خلال:</p>
          </div>
          <div className="flex gap-3 tabular-nums" dir="ltr">
            {[h, m, s].map((v, i) => (
              <div key={i} className="flex h-20 w-20 flex-col items-center justify-center border border-gold/40">
                <span className="font-display text-3xl text-gold">{v}</span>
                <span className="text-[10px] tracking-widest opacity-60">{["HRS", "MIN", "SEC"][i]}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="mx-auto grid max-w-7xl grid-cols-2 gap-px bg-border px-0 md:grid-cols-4">
        {STATS.map((st) => (
          <div key={st.l} className="bg-background px-6 py-12 text-center">
            <div className="font-display text-4xl" dir="ltr">{st.n}</div>
            <div className="mt-2 text-sm text-muted-foreground">{st.l}</div>
          </div>
        ))}
      </section>

      {/* FEATURED */}
      <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
        <div className="mb-12 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="mb-3 text-xs font-bold tracking-[0.3em] text-gold">FEATURED</p>
            <h2 className="font-display text-4xl md:text-5xl">منتجاتنا المميزة</h2>
            <p className="mt-3 text-muted-foreground">اكتشفي مجموعتنا الفاخرة من أرقى العلامات التجارية العالمية</p>
          </div>
          <Link to="/products" className="text-sm font-medium underline underline-offset-8 hover:text-gold">
            عرض جميع المنتجات
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-x-5 gap-y-12 md:grid-cols-3 lg:grid-cols-4">
          {featured.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      </section>

      {/* REVIEWS */}
      <section className="bg-secondary">
        <div className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
          <h2 className="text-center font-display text-4xl md:text-5xl">آراء عملائنا الكرام</h2>
          <p className="mt-3 text-center text-muted-foreground">استمعي لتجارب عميلاتنا المميزات</p>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {REVIEWS.map((r, i) => (
              <motion.figure
                key={r.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.6 }}
                className="bg-card p-8"
              >
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Star key={k} className="h-4 w-4 fill-gold text-gold" />
                  ))}
                </div>
                <blockquote className="mt-5 font-display text-lg leading-relaxed">"{r.text}"</blockquote>
                <figcaption className="mt-6 text-sm font-bold">{r.name}</figcaption>
              </motion.figure>
            ))}
          </div>
        </div>
      </section>

      {/* NEWSLETTER */}
      <section className="mx-auto max-w-3xl px-5 py-24 text-center">
        <h3 className="font-display text-4xl">اشتركي في نشرتنا البريدية</h3>
        <p className="mt-3 text-muted-foreground">احصلي على أحدث العروض والمنتجات الحصرية</p>
        <form onSubmit={subscribe} className="mx-auto mt-8 flex max-w-lg border border-foreground">
          <input
            name="email"
            type="email"
            required
            maxLength={255}
            dir="ltr"
            placeholder="email@example.com"
            className="h-14 flex-1 bg-transparent px-5 text-sm outline-none"
          />
          <button className="h-14 bg-primary px-8 text-sm font-medium text-primary-foreground">اشتراك</button>
        </form>
      </section>
    </>
  );
}
