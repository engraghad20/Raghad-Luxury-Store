import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { Search, X } from "lucide-react";
import { categoriesQuery, productsQuery } from "@/lib/store";
import { ProductCard } from "@/components/store/ProductCard";
import { cn } from "@/lib/utils";

type Sort = "featured" | "rating" | "price-asc" | "price-desc";
type SearchParams = { q?: string | undefined; brand?: string | undefined; sort?: Sort | undefined };

export const Route = createFileRoute("/products")({
  validateSearch: (s: Record<string, unknown>): SearchParams => ({
    q: typeof s["q"] === "string" && s["q"] ? s["q"].slice(0, 80) : undefined,
    brand: typeof s["brand"] === "string" && s["brand"] ? s["brand"] : undefined,
    sort: ["featured", "rating", "price-asc", "price-desc"].includes(s["sort"] as string) ? (s["sort"] as Sort) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "جميع المنتجات — Raghade' Luxury" },
      { name: "description", content: "تصفحي 23 منتجاً فاخراً من KIKO وLuxora وBellezza وYves Saint Laurent مع البحث والتصفية." },
      { property: "og:title", content: "جميع المنتجات — Raghade' Luxury" },
      { property: "og:description", content: "أحمر شفاه فاخر من أرقى العلامات العالمية." },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([context.queryClient.ensureQueryData(productsQuery()), context.queryClient.ensureQueryData(categoriesQuery())]),
  component: ProductsPage,
});

function ProductsPage() {
  const { q, brand, sort = "featured" } = Route.useSearch();
  const navigate = useNavigate({ from: "/products" });
  const { data: products } = useSuspenseQuery(productsQuery());
  const { data: categories } = useSuspenseQuery(categoriesQuery());

  const list = useMemo(() => {
    const term = (q ?? "").toLowerCase();
    let r = products.filter(
      (p) =>
        (!brand || p.category?.slug === brand) &&
        (!term || [p.name, p.brand, p.description].some((f) => f.toLowerCase().includes(term))),
    );
    r = [...r];
    if (sort === "rating") r.sort((a, b) => b.rating - a.rating);
    if (sort === "price-asc") r.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") r.sort((a, b) => b.price - a.price);
    return r;
  }, [products, q, brand, sort]);

  const set = (patch: Partial<SearchParams>) => navigate({ search: (prev) => ({ ...prev, ...patch }), replace: true });

  return (
    <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
      <p className="mb-3 text-xs font-bold tracking-[0.3em] text-gold">COLLECTION</p>
      <h1 className="font-display text-5xl">جميع المنتجات</h1>

      <div className="sticky top-20 z-30 -mx-5 mt-10 flex flex-wrap items-center gap-3 border-y border-border bg-background/90 px-5 py-4 backdrop-blur lg:mx-0 lg:px-0">
        <div className="flex flex-wrap gap-2">
          {[{ slug: undefined, name: "الكل" }, ...categories].map((c) => (
            <button
              key={c.name}
              onClick={() => set({ brand: c.slug })}
              className={cn(
                "h-9 rounded-full border px-4 text-sm transition",
                brand === c.slug ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-foreground",
              )}
            >
              {c.name}
            </button>
          ))}
        </div>
        <div className="ms-auto flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              key={q ?? ""}
              defaultValue={q}
              onChange={(e) => set({ q: e.target.value || undefined })}
              placeholder="بحث..."
              className="h-9 w-48 rounded-full border border-border bg-card ps-9 pe-8 text-sm outline-none focus:border-gold"
            />
            {q && (
              <button onClick={() => set({ q: undefined })} className="absolute end-2 top-1/2 -translate-y-1/2" aria-label="مسح">
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            )}
          </div>
          <select
            value={sort}
            onChange={(e) => set({ sort: e.target.value as Sort })}
            className="h-9 rounded-full border border-border bg-card px-3 text-sm outline-none"
            aria-label="الترتيب"
          >
            <option value="featured">الترتيب الافتراضي</option>
            <option value="rating">الأعلى تقييماً</option>
            <option value="price-asc">السعر: من الأقل</option>
            <option value="price-desc">السعر: من الأعلى</option>
          </select>
        </div>
      </div>

      <p className="mt-6 text-sm text-muted-foreground">{list.length} منتج</p>
      {list.length === 0 ? (
        <div className="py-24 text-center">
          <p className="font-display text-2xl">لا توجد نتائج مطابقة</p>
          <button onClick={() => navigate({ search: {} })} className="mt-4 text-sm underline underline-offset-4">
            إعادة ضبط التصفية
          </button>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-x-5 gap-y-12 md:grid-cols-3 lg:grid-cols-4">
          {list.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      )}
    </div>
  );
}
