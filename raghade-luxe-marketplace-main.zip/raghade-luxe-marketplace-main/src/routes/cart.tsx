import { createFileRoute, Link } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { useCart } from "@/lib/cart";
import { sar } from "@/lib/pricing";
import { Summary } from "@/components/store/Summary";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "سلة التسوق — Raghade' Luxury" },
      { name: "description", content: "راجعي منتجاتك وعدّلي الكميات قبل إتمام الطلب." },
      { property: "og:title", content: "سلة التسوق — Raghade' Luxury" },
      { property: "og:description", content: "سلة التسوق الخاصة بك." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { items, setQty, remove, totals } = useCart();

  if (items.length === 0)
    return (
      <div className="mx-auto max-w-xl px-5 py-32 text-center">
        <ShoppingBag className="mx-auto h-10 w-10 text-gold" />
        <h1 className="mt-6 font-display text-4xl">سلة التسوق فارغة</h1>
        <p className="mt-3 text-muted-foreground">ابدئي التسوق واكتشفي مجموعتنا الفاخرة</p>
        <Link to="/products" className="mt-8 inline-flex h-12 items-center bg-primary px-8 text-sm text-primary-foreground">
          تسوقي الآن
        </Link>
      </div>
    );

  return (
    <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
      <h1 className="font-display text-5xl">سلة التسوق</h1>
      <div className="mt-10 grid gap-12 lg:grid-cols-3">
        <ul className="divide-y divide-border border-y border-border lg:col-span-2">
          <AnimatePresence initial={false}>
            {items.map((i) => (
              <motion.li key={i.id} layout exit={{ opacity: 0, x: 40 }} className="flex gap-5 py-6">
                <img src={i.image_url} alt={i.name} className="h-32 w-24 object-cover" />
                <div className="flex flex-1 flex-col">
                  <div className="flex justify-between gap-3">
                    <div>
                      <div className="text-[11px] font-bold tracking-[0.2em] text-gold" dir="ltr">{i.brand.toUpperCase()}</div>
                      <div className="font-display text-lg">{i.name}</div>
                      <div className="text-sm text-muted-foreground">{sar(i.price)}</div>
                    </div>
                    <button onClick={() => remove(i.id)} aria-label="حذف" className="self-start text-muted-foreground hover:text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="mt-auto flex items-center justify-between">
                    <div className="flex items-center border border-border">
                      <button onClick={() => setQty(i.id, i.quantity + 1)} className="flex h-9 w-9 items-center justify-center" aria-label="زيادة">
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                      <span className="w-8 text-center text-sm tabular-nums">{i.quantity}</span>
                      <button onClick={() => setQty(i.id, i.quantity - 1)} className="flex h-9 w-9 items-center justify-center" aria-label="إنقاص">
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <span className="font-semibold">{sar(i.price * i.quantity)}</span>
                  </div>
                </div>
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>
        <div>
          <Summary totals={totals} />
          <Link to="/checkout" className="mt-4 flex h-14 w-full items-center justify-center bg-primary text-sm font-medium tracking-wide text-primary-foreground">
            إتمام الطلب
          </Link>
          <Link to="/products" className="mt-3 block text-center text-sm text-muted-foreground underline-offset-4 hover:underline">
            متابعة التسوق
          </Link>
        </div>
      </div>
    </div>
  );
}
