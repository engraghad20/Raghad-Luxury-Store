import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "من نحن — Raghade' Luxury" },
      { name: "description", content: "Raghade' Luxury وجهتك الأولى لأفخم منتجات المكياج العالمية. تعرّفي على رؤيتنا ولماذا تختاريننا." },
      { property: "og:title", content: "من نحن — Raghade' Luxury" },
      { property: "og:description", content: "كل امرأة تستحق أن تشعر بالجمال والثقة." },
    ],
  }),
  component: About,
});

const WHY = [
  "منتجات أصلية 100% من علامات تجارية عالمية معتمدة",
  "شحن سريع وآمن لجميع مناطق المملكة",
  "أسعار تنافسية مع عروض حصرية مستمرة",
  "تغليف فاخر يليق بذوقك الرفيع",
  "خدمة عملاء متميزة على مدار الساعة",
  "دفع آمن ومضمون بأحدث تقنيات الحماية",
];

function About() {
  return (
    <div className="mx-auto max-w-5xl px-5 py-20 lg:px-8">
      <p className="mb-3 text-xs font-bold tracking-[0.3em] text-gold">ABOUT</p>
      <h1 className="font-display text-5xl md:text-6xl">راغدي الفاخر</h1>
      <p className="mt-8 max-w-3xl text-xl leading-loose text-muted-foreground">
        <span dir="ltr">Raghade' Luxury</span> هو وجهتك الأولى للحصول على أفخم منتجات المكياج العالمية. نحن نؤمن بأن كل امرأة
        تستحق أن تشعر بالجمال والثقة، ولهذا نقدم لك مجموعة مختارة بعناية من أرقى العلامات التجارية العالمية.
      </p>

      <div className="mt-20 grid gap-12 border-t border-border pt-12 md:grid-cols-3">
        <h2 className="font-display text-3xl">رؤيتنا</h2>
        <p className="text-lg leading-loose text-muted-foreground md:col-span-2">
          نسعى لأن نكون الخيار الأول للمرأة العصرية التي تبحث عن التميز والأناقة في كل تفصيلة. نقدم تجربة تسوق استثنائية تجمع بين
          الفخامة والراحة والأسعار التنافسية.
        </p>
      </div>

      <div className="mt-16 grid gap-12 border-t border-border pt-12 md:grid-cols-3">
        <h2 className="font-display text-3xl">لماذا تختاريننا؟</h2>
        <ul className="grid gap-px bg-border sm:grid-cols-2 md:col-span-2">
          {WHY.map((w, i) => (
            <li key={w} className="flex gap-4 bg-background p-6">
              <span className="font-display text-gold" dir="ltr">0{i + 1}</span>
              <span>{w}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
