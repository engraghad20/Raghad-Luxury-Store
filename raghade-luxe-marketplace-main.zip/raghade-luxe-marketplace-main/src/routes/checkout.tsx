import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/auth";
import { PAYMENT_METHODS, type Invoice } from "@/lib/store";
import { Summary } from "@/components/store/Summary";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "إتمام الطلب — Raghade' Luxury" },
      { name: "description", content: "أدخلي بيانات التوصيل واختاري طريقة الدفع لإتمام طلبك." },
      { property: "og:title", content: "إتمام الطلب — Raghade' Luxury" },
      { property: "og:description", content: "إتمام الطلب بأمان." },
    ],
  }),
  component: Checkout,
});

const field = "h-12 w-full border border-input bg-card px-4 text-sm outline-none transition focus:border-gold";

function Checkout() {
  const { items, totals, clear } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [profile, setProfile] = useState<{ full_name?: string | null; phone?: string | null; city?: string | null; address?: string | null }>({});

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("full_name,phone,city,address").eq("id", user.id).maybeSingle().then(({ data }) => data && setProfile(data));
  }, [user]);

  if (items.length === 0)
    return (
      <div className="py-32 text-center">
        <h1 className="font-display text-3xl">لا توجد منتجات في السلة</h1>
        <Link to="/products" className="mt-6 inline-block underline">تسوقي الآن</Link>
      </div>
    );

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const g = (k: string) => String(f.get(k) ?? "").trim();
    setBusy(true);
    const { data, error } = await supabase.rpc("place_order", {
      _items: items.map((i) => ({ product_id: i.id, quantity: i.quantity })),
      _full_name: g("full_name"),
      _phone: g("phone"),
      _email: g("email"),
      _city: g("city"),
      _address: g("address"),
      _payment_method: g("payment"),
    });
    setBusy(false);
    if (error) { toast.error(error.message || "تعذر إتمام الطلب"); return; }
    if (user) {
      await supabase.from("profiles").update({ full_name: g("full_name"), phone: g("phone"), city: g("city"), address: g("address") }).eq("id", user.id);
    }
    sessionStorage.setItem("rl-last-invoice", JSON.stringify(data as unknown as Invoice));
    clear();
    navigate({ to: "/order-success" });
  }

  return (
    <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
      <h1 className="font-display text-5xl">إتمام الطلب</h1>
      <form onSubmit={submit} className="mt-10 grid gap-12 lg:grid-cols-3" key={user?.id ?? "guest"}>
        <div className="space-y-5 lg:col-span-2">
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="space-y-2 text-sm">الاسم الكامل *<input name="full_name" required maxLength={120} defaultValue={profile.full_name ?? ""} placeholder="أدخلي اسمك الكامل" className={field} /></label>
            <label className="space-y-2 text-sm">رقم الجوال *<input name="phone" type="tel" required maxLength={30} pattern="[+0-9 ]{8,}" defaultValue={profile.phone ?? ""} dir="ltr" placeholder="+966 5X XXX XXXX" className={field} /></label>
            <label className="space-y-2 text-sm">البريد الإلكتروني *<input name="email" type="email" required maxLength={255} defaultValue={user?.email ?? ""} dir="ltr" placeholder="example@email.com" className={field} /></label>
            <label className="space-y-2 text-sm">المدينة *<input name="city" required maxLength={80} defaultValue={profile.city ?? ""} placeholder="الرياض" className={field} /></label>
          </div>
          <label className="block space-y-2 text-sm">العنوان الكامل *<input name="address" required maxLength={300} defaultValue={profile.address ?? ""} placeholder="الحي، الشارع، رقم المبنى" className={field} /></label>
          <fieldset className="space-y-3">
            <legend className="mb-3 text-sm">طريقة الدفع *</legend>
            <div className="grid gap-3 sm:grid-cols-2">
              {PAYMENT_METHODS.map((m, i) => (
                <label key={m} className="flex cursor-pointer items-center gap-3 border border-input bg-card p-4 text-sm has-[:checked]:border-gold has-[:checked]:bg-secondary">
                  <input type="radio" name="payment" value={m} defaultChecked={i === 0} className="accent-[var(--gold)]" />
                  {m}
                </label>
              ))}
            </div>
          </fieldset>
        </div>
        <div>
          <Summary totals={totals} />
          <button disabled={busy} className="mt-4 h-14 w-full bg-primary text-sm font-medium tracking-wide text-primary-foreground disabled:opacity-60">
            {busy ? "جارٍ تأكيد الطلب..." : "تأكيد الطلب وإتمام الدفع"}
          </button>
        </div>
      </form>
    </div>
  );
}
