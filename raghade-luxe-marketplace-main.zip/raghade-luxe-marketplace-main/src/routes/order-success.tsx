import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Printer } from "lucide-react";
import type { Invoice } from "@/lib/store";
import { sar } from "@/lib/pricing";

export const Route = createFileRoute("/order-success")({
  head: () => ({
    meta: [
      { title: "تم الطلب بنجاح — Raghade' Luxury" },
      { name: "description", content: "فاتورة طلبك من Raghade' Luxury." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "تم الطلب بنجاح — Raghade' Luxury" },
      { property: "og:description", content: "شكراً لثقتك بنا." },
    ],
  }),
  component: Success,
});

function Success() {
  const [inv, setInv] = useState<Invoice | null | undefined>(undefined);
  useEffect(() => {
    try {
      setInv(JSON.parse(sessionStorage.getItem("rl-last-invoice") ?? "null"));
    } catch {
      setInv(null);
    }
  }, []);

  if (inv === undefined) return <div className="py-32" />;
  if (!inv)
    return (
      <div className="py-32 text-center">
        <h1 className="font-display text-3xl">لا توجد فاتورة لعرضها</h1>
        <Link to="/" className="mt-6 inline-block underline">العودة للرئيسية</Link>
      </div>
    );

  const o = inv.order;
  return (
    <div className="mx-auto max-w-3xl px-5 py-16">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="no-print text-center">
        <CheckCircle2 className="mx-auto h-12 w-12 text-success" />
        <h1 className="mt-4 font-display text-4xl">تم الطلب بنجاح!</h1>
        <p className="mt-2 text-muted-foreground">شكراً لثقتك بنا. سيتم توصيل طلبك في أقرب وقت ممكن</p>
      </motion.div>

      <article className="mt-10 border border-border bg-card p-8 md:p-12">
        <header className="flex flex-wrap items-start justify-between gap-4 border-b border-border pb-6">
          <div>
            <div className="font-display text-2xl" dir="ltr">Raghade' <span className="text-gold-gradient">Luxury</span></div>
            <div className="mt-1 text-xs text-muted-foreground">فاتورة ضريبية مبسطة</div>
          </div>
          <div className="text-sm">
            <div>رقم الطلب: <span className="font-bold" dir="ltr">{o.order_number}</span></div>
            <div className="text-muted-foreground">{new Date(o.created_at).toLocaleString("ar-SA-u-nu-latn")}</div>
          </div>
        </header>
        <section className="grid gap-1 border-b border-border py-6 text-sm sm:grid-cols-2">
          <div><span className="text-muted-foreground">العميلة: </span>{o.full_name}</div>
          <div><span className="text-muted-foreground">الجوال: </span><span dir="ltr">{o.phone}</span></div>
          <div><span className="text-muted-foreground">البريد: </span><span dir="ltr">{o.email}</span></div>
          <div><span className="text-muted-foreground">الدفع: </span>{o.payment_method}</div>
          <div className="sm:col-span-2"><span className="text-muted-foreground">العنوان: </span>{o.city} — {o.address}</div>
        </section>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-muted-foreground">
              <th className="py-3 text-right font-normal">المنتج</th>
              <th className="py-3 text-center font-normal">الكمية</th>
              <th className="py-3 text-left font-normal">السعر</th>
            </tr>
          </thead>
          <tbody>
            {inv.items.map((it) => (
              <tr key={it.id} className="border-b border-border">
                <td className="py-3">{it.product_name} <span className="text-xs text-muted-foreground">· {it.brand}</span></td>
                <td className="py-3 text-center">{it.quantity}</td>
                <td className="py-3 text-left">{sar(Number(it.unit_price) * it.quantity)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <dl className="ms-auto mt-6 max-w-xs space-y-2 text-sm">
          <div className="flex justify-between"><dt>المجموع الفرعي</dt><dd>{sar(o.subtotal)}</dd></div>
          <div className="flex justify-between"><dt>التوفير</dt><dd className="text-success">−{sar(o.discount)}</dd></div>
          <div className="flex justify-between"><dt>الضريبة (15%)</dt><dd>{sar(o.tax)}</dd></div>
          <div className="flex justify-between border-t border-border pt-3 text-base font-bold"><dt>الإجمالي</dt><dd>{sar(o.total)}</dd></div>
        </dl>
      </article>

      <div className="no-print mt-8 flex flex-wrap justify-center gap-3">
        <button onClick={() => window.print()} className="inline-flex h-12 items-center gap-2 bg-primary px-6 text-sm text-primary-foreground">
          <Printer className="h-4 w-4" /> طباعة الفاتورة
        </button>
        <Link to="/" className="inline-flex h-12 items-center border border-foreground px-6 text-sm">العودة للرئيسية</Link>
      </div>
    </div>
  );
}
