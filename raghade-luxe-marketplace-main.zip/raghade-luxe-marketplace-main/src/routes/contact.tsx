import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpLeft, Github, Linkedin, Mail, Twitter } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "تواصلي معنا — Raghade' Luxury" },
      { name: "description", content: "نحن دائماً في خدمتك! تواصلي مع Raghade' Luxury عبر البريد الإلكتروني وGitHub وLinkedIn وTwitter." },
      { property: "og:title", content: "تواصلي معنا — Raghade' Luxury" },
      { property: "og:description", content: "نحن دائماً في خدمتك." },
    ],
  }),
  component: Contact,
});

const CHANNELS = [
  { icon: Mail, title: "البريد الإلكتروني", value: "raghad.alshawafy2023@icloud.com", href: "mailto:raghad.alshawafy2023@icloud.com" },
  { icon: Github, title: "GitHub", value: "github.com/engraghad20", href: "https://github.com/engraghad20" },
  { icon: Linkedin, title: "LinkedIn", value: "Raghad Alshawafy", href: "https://www.linkedin.com/search/results/all/?keywords=Raghad%20Alshawafy" },
  { icon: Twitter, title: "Twitter", value: "@engraghad02", href: "https://twitter.com/engraghad02" },
];

function Contact() {
  return (
    <div className="mx-auto max-w-5xl px-5 py-20 lg:px-8">
      <p className="mb-3 text-xs font-bold tracking-[0.3em] text-gold">CONTACT</p>
      <h1 className="font-display text-5xl md:text-6xl">تواصلي معنا</h1>
      <p className="mt-6 text-lg text-muted-foreground">نحن دائماً في خدمتك! تواصلي معنا عبر القنوات التالية</p>
      <div className="mt-14 grid gap-px bg-border sm:grid-cols-2">
        {CHANNELS.map((c) => (
          <a key={c.title} href={c.href} target="_blank" rel="noreferrer" className="group flex items-start justify-between bg-background p-8 transition hover:bg-secondary">
            <div>
              <c.icon className="h-6 w-6 text-gold" />
              <h3 className="mt-6 font-display text-2xl">{c.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground" dir="ltr">{c.value}</p>
            </div>
            <ArrowUpLeft className="h-5 w-5 opacity-0 transition group-hover:opacity-100" />
          </a>
        ))}
      </div>
    </div>
  );
}
